package v3_mosaik_generator;

public interface Stein 
{
	
	public String getFarbe();
	public double getFlaeche();
	public String getTyp();
	
}
